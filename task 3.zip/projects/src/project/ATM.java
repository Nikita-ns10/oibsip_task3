package project;
import java.util.ArrayList;
import java.util.Scanner;

class User {
    private String userId;
    private String userPin;

    public User(String userId, String userPin) {
        this.userId = userId;
        this.userPin = userPin;
    }

    public String getUserId() {
        return userId;
    }

    public String getUserPin() {
        return userPin;
    }
}

class Transaction {
    public static void showTransactionHistory(ArrayList<String> history) {
        System.out.println("---------------------");
        System.out.println("Transaction History:");
        if (history.isEmpty()) {
            System.out.println("No transactions yet.");
        } else {
            for (String transaction : history) {
                System.out.println(transaction);
            }
        }
        System.out.println("---------------------");
    }

    public static void withdraw(int amount, ArrayList<String> history) {
        history.add("Withdraw: " + amount);
        System.out.println("Withdrawn Rs." + amount + "/- successfully");
    }

    public static void deposit(int amount, ArrayList<String> history) {
        history.add("Deposit: " + amount);
        System.out.println("Deposited Rs." + amount + "/- successfully");
    }

    public static void transfer(int amount, String recipient, ArrayList<String> history) {
        history.add("Transferred Rs." + amount + "/- to " + recipient);
        System.out.println("Transferred Rs." + amount + "/- to " + recipient + " successfully");
    }
}

public class ATM {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<String> transactionHistory = new ArrayList<>();

        // Simulated user data (in a real scenario, this would be fetched or validated against a database)
        String UserId = "user13";
        String UserPin = "1234";

        // Prompt for user ID and PIN
        System.out.println("---------------------------");
        System.out.println("WelCome To Atm");
        System.out.print("Enter User ID: ");
        String userId = scanner.nextLine();
        System.out.print("Enter User PIN: ");
        String userPin = scanner.nextLine();

        // Validate user credentials
        if (userId.equals(UserId) && userPin.equals(UserPin)) {
            System.out.println("Login successful!");

            // ATM operations
            while (true) {
                System.out.println("---------------------");
                System.out.println("Select an option:");
                System.out.println("1. View Transaction History");
                System.out.println("2. Withdraw");
                System.out.println("3. Deposit");
                System.out.println("4. Transfer");
                System.out.println("5. Quit");

                System.out.print("Enter your choice: ");
                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline left-over

                switch (choice) {
                    case 1:
                        Transaction.showTransactionHistory(transactionHistory);
                        break;
                    case 2:
                        System.out.print("Enter amount to withdraw: ");
                        int withdrawAmount = scanner.nextInt();
                        Transaction.withdraw(withdrawAmount, transactionHistory);
                        break;
                    case 3:
                        System.out.print("Enter amount to deposit: ");
                        int depositAmount = scanner.nextInt();
                        Transaction.deposit(depositAmount, transactionHistory);
                        break;
                    case 4:
                        System.out.print("Enter amount to transfer: ");
                        int transferAmount = scanner.nextInt();
                        scanner.nextLine(); // Consume newline left-over
                        System.out.print("Enter recipient's name: ");
                        String recipient = scanner.nextLine();
                        Transaction.transfer(transferAmount, recipient, transactionHistory);
                        break;
                    case 5:
                        System.out.println("Thank you for using our ATM. Goodbye!");
                        System.exit(0);
                    default:
                        System.out.println("Invalid choice. Please enter a number between 1 and 5.");
                }
            }
        } else {
            System.out.println("Invalid credentials. Exiting...");
        }

        scanner.close();
    }
}
